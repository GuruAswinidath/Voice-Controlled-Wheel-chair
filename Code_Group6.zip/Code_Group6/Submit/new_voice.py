import RPi.GPIO as GPIO
import curses
import speech_recognition as sr
from threading import Thread, Event
import time

# Define GPIO pin numbers
motor1_forward_pin = 19
motor1_reverse_pin = 23
motor2_forward_pin = 29
motor2_reverse_pin = 22

def turn_left_90():
    control_motors(GPIO.HIGH, GPIO.LOW, GPIO.LOW, GPIO.HIGH)
    time.sleep(1)  # Adjust this delay to make precise left turn
    stop()

# Function to control the motors
def control_motors(motor1_forward, motor1_reverse, motor2_forward, motor2_reverse):
    GPIO.output(motor1_forward_pin, motor1_forward)
    GPIO.output(motor1_reverse_pin, motor1_reverse)
    GPIO.output(motor2_forward_pin, motor2_forward)
    GPIO.output(motor2_reverse_pin, motor2_reverse)

# Function to stop the robot
def stop():
    control_motors(GPIO.LOW, GPIO.LOW, GPIO.LOW, GPIO.LOW)

# Function for speech recognition
def recognize_speech(stop_event):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source)
        recognizer.dynamic_energy_threshold = True
        recognizer.pause_threshold = 0.5

        while not stop_event.is_set():
            print("Start Talking...")
            try:
                audio_text = recognizer.listen(source, timeout=1)
                print("Recognizing...")
                final_text = recognizer.recognize_google(audio_text)
                final_text_lower = final_text.lower()
                print("Completed: ", final_text_lower)
                process_command(final_text_lower)
            except sr.WaitTimeoutError:
                pass
            except Exception as e:
                print("Error during speech recognition:", str(e))
# Function to process the speech command
def process_command(command):
    if "front" in command:
        control_motors(GPIO.HIGH, GPIO.LOW, GPIO.LOW, GPIO.HIGH)
    elif "back" in command:
        control_motors(GPIO.LOW, GPIO.HIGH, GPIO.HIGH, GPIO.LOW)
    elif "left" in command:
        control_motors(GPIO.HIGH, GPIO.LOW, GPIO.HIGH, GPIO.LOW)
    elif "right" in command:
        control_motors(GPIO.LOW, GPIO.HIGH, GPIO.LOW, GPIO.HIGH)
    elif "stop" in command:
        stop()
# Main control loop
def main(stdscr):
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(motor1_forward_pin, GPIO.OUT)
    GPIO.setup(motor1_reverse_pin, GPIO.OUT)
    GPIO.setup(motor2_forward_pin, GPIO.OUT)
    GPIO.setup(motor2_reverse_pin, GPIO.OUT)

    stop_event = Event()

    try:
        curses.cbreak()
        stdscr.keypad(True)

        # Start the speech recognition thread
        speech_thread = Thread(target=recognize_speech, args=(stop_event,))
        speech_thread.daemon = True
        speech_thread.start()

        # Wait for user input (pressing 'q' to exit the program)
        while True:
            key = stdscr.getch()
            if key == ord("q"):  # Press 'q' to exit the program
                stop_event.set()
                break
            elif key == ord("w"):
                # Move the wheelchair forward when 'w' key is pressed
                control_motors(GPIO.HIGH, GPIO.LOW, GPIO.LOW, GPIO.HIGH)
            elif key == ord("s"):
                # Move the wheelchair backward when 's' key is pressed
                control_motors(GPIO.LOW, GPIO.HIGH, GPIO.HIGH, GPIO.LOW)
            elif key == ord("a"):
                # Turn the wheelchair left when 'a' key is pressed
                control_motors(GPIO.HIGH, GPIO.LOW, GPIO.HIGH, GPIO.LOW)
            elif key == ord("d"):
                # Turn the wheelchair right when 'd' key is pressed
                control_motors(GPIO.LOW, GPIO.HIGH, GPIO.LOW, GPIO.HIGH)

    finally:
        stop()
        time.sleep(0.2)  # Small delay after stopping to ensure responsiveness
        curses.nocbreak()
        stdscr.keypad(False)
        curses.echo()
        curses.endwin()
        GPIO.cleanup()

if __name__ == "__main__":
    curses.wrapper(main)


